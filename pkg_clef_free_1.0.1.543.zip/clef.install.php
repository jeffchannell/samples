<?php
/**
 * @package		Clef
 * @subpackage	pkg_clef

**********************************************
Clef
Copyright (c) 2015 Anything-Digital.com
**********************************************
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This header must not be removed. Additional contributions/changes
may be added to this header as long as no information is deleted.
**********************************************

 */

defined('JPATH_PLATFORM') or die;

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

class pkg_ClefInstallerScript
{
	protected $db;
	
	protected $lang;
	
	function __construct()
	{
		$this->app  = JFactory::getApplication();
		$this->db   = JFactory::getDbo();
		$this->lang = JFactory::getLanguage();
	}
	
	public function preflight($type, $parent)
	{
		$path = $this->getSourcePath($parent) . '/languages/';
		
		// check path first
		if (!JFolder::exists($path))
		{
			$path = JPATH_ADMINISTRATOR;
		}
		
		$this->lang->load('pkg_clef.sys', $path);
	}
	
	public function postflight($type, $parent)
	{
		if ('uninstall' == $type)
		{
			return;
		}
		$redirect = true;
		
		try
		{
			// enable the plugins
			$this->enablePlugin('system');
			$this->enablePlugin('authentication', array('ordering' => $this->getMinPluginOrder()));
			// enable the admin module
			$this->enableAdminModule();
		}
		catch (Exception $e)
		{
			$redirect = false;
			$this->app->enqueueMessage($e->getMessage(), 'error');
		}
		// redirect if necessary
		if ($redirect)
		{
			// DO NOT redirect from here - will cause issues with code cleanup and update servers!
			$this->app->enqueueMessage('<script type="text/javascript">window.location.href=\'' . JRoute::_('index.php?option=com_clef') . '\';</script>');
		}
	}
	
	/**
	 * Gets the tmp folder storing the files from the package
	 * 
	 * @param type $parent
	 * @return type
	 */
	private function getSourcePath($parent)
	{
		if (method_exists($parent, 'source'))
		{
			return $parent->getPath('source');
		}
		return $parent->getParent()->getPath('source');
	}
	
	/**
	 * Enables a clef plugin in the core extensions database table
	 * 
	 * @param string $folder
	 * @param array  $extra
	 */
	private function enablePlugin($folder, $extra = array())
	{
		$set = $this->db->quoteName('enabled') . ' = ' . $this->db->quote('1');
		if (!empty($extra))
		{
			foreach ($extra as $key => $value)
			{
				$set .= ', ' . $this->db->quoteName($key) . ' = ' . $this->db->quote($value);
			}
		}
		$this->db->setQuery($this->db->getQuery(true)
			->update($this->db->quoteName('#__extensions'))
			->set($set)
			->where($this->db->quoteName('element') . ' = ' . $this->db->quote('clef'))
			->where($this->db->quoteName('folder') . ' = ' . $this->db->quote($folder))
			->where($this->db->quoteName('type') . ' = ' . $this->db->quote('plugin'))
		)->query();
	}
	
	/**
	 * Enables the admin module
	 * 
	 * @throws UnexpectedValueException
	 */
	private function enableAdminModule()
	{
		// find the module 
		$module = $this->db->setQuery($this->db->getQuery(true)
			->select('id, published')
			->from($this->db->quoteName('#__modules'))
			->where($this->db->quoteName('client_id') . ' = ' . $this->db->quote('1'))
			->where($this->db->quoteName('module') . ' = ' . $this->db->quote('mod_clefadmin'))
		)->loadObject();
		// error if none found
		if (empty($module))
		{
			throw new UnexpectedValueException(JText::_('PKG_CLEF_CANNOT_FIND_ADMIN_MODULE'));
		}
		// only continue if the module is not published
		if (0 === (int) $module->published)
		{
			// enable it
			$this->db->setQuery($this->db->getQuery(true)
				->update($this->db->quoteName('#__modules'))
				->set($this->db->quoteName('published') . ' = ' . $this->db->quote('1') . ',' . $this->db->quoteName('position') . ' = ' . $this->db->quote('login'))
				->where($this->db->quoteName('id') . ' = ' . $this->db->quote($module->id))
			)->query();
			// remove it from the menu
			$this->db->setQuery($this->db->getQuery(true)
				->delete($this->db->quoteName('#__modules_menu'))
				->where($this->db->quoteName('moduleid') . ' = ' . $this->db->quote($module->id))
			)->query();
			// add it back
			$this->db->setQuery($this->db->getQuery(true)
				->insert($this->db->quoteName('#__modules_menu'))
				->columns(array($this->db->quoteName('moduleid'), $this->db->quoteName('menuid')))
				->values($this->db->quote($module->id) . ', ' . $this->db->quote('0'))
			)->query();
		}
	}
	
	protected function getMinPluginOrder()
	{
		return (int) $this->db->setQuery($this->db->getQuery(true)
			->select('MIN(ordering) - 1')
			->from('#__extensions')
			->where($this->db->quoteName('element') . ' <> ' . $this->db->quote('clef'))
			->where($this->db->quoteName('type') . ' = ' . $this->db->quote('plugin'))
		)->loadResult();
	}
}
