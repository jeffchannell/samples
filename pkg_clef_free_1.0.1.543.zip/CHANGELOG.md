# clef4joomla
All notable changes to this project will be documented in this file

## [1.0.1] - 2015-05-08
### Changed
- Updated copyright header
- Added CHANGELOG.md

### Security
- Added state parameter for CSRF protection

## [1.0.0] - 2014-05-30
### Added
- Initial public release
